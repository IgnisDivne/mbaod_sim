library(PopED)

PKPD.fg <- function(x,a,bpop,b,bocc){
  ## -- parameter definition function

  parameters=c( CL   = bpop[1]*exp(b[1]),
                V    = bpop[2]*exp(b[2]),
                Ka   = bpop[3]*exp(b[3]),
                Base = bpop[4]*exp(b[4]),
                EMAX = bpop[5]*exp(b[5]),
                EC50 = bpop[6]*exp(b[6]),
                hill = bpop[7]*exp(b[7]),
                Dose = a[1]
                )
  return( parameters )
}


PKPD.ff <- function(model_switch,xt,parameters,poped.db){
  with(as.list(parameters),{
    y=xt
    Ke=CL/V
    
    C = ((Dose*Ka*Ke)/(CL(Ka-Ke)))*(exp(-Ke*xt)-exp(-Ka*xt))
    y = Base*((C^hill*EMAX)/(EC50^hill + C^hill))
    
    
       
    return(list( y= y,poped.db=poped.db))
  })
}

