
#set path to the directory where this file is located
setwd("C:/Users/erist836/Desktop/MBAOD2")

# remove things from the global environment
rm(list=ls())

library(PopED)
library(mvtnorm)
library(xpose4)

# load the MBAOD package, change to your relevant load call
devtools::load_all("C:/Users/erist836/Documents/GitHub/MBAOD/R")

# load the PopED model file
source("PopED_files/PKPD_example_1.R")

############################################RUN THIS SECTION FOR MBAOD WITH SMALL Misspecification############################################
#Adults
step_1=list(
  design = list(
    groupsize = 4,
    m=4,
    a = list(c(AMT=20),c(AMT=40),c(AMT=80),c(AMT=160)),
    xt = c(0.5,2,3,6,24,36,72,120)
  ),
  optimize=NULL,
  simulate=list(target="NONMEM", model="NONMEM_files/ex1_sim.mod",
                data=list(dosing = list(list(AMT0=1,Time=0)),
                          manipulation = list(expression(AMT <- AMT0*AMT))
                )
                
  ),
  estimate=list(target="NONMEM", model="NONMEM_files/ex1_est_full.mod")
)




#First cohort with dose optimization
step_2 = list(
  design = list(
    groupsize = 1,
    m=4,
    a = list(c(AMT=20),c(AMT=40),c(AMT=80),c(AMT=160)),
    xt = c(0.5,2,3,6,24,36,72,120)
  ),
  optimize=list(target="poped_R",
                model = list(
                  ff_file="PK.1.comp.maturation.ff",
                  fError_file="feps.add.prop",
                  fg_file="PK.1.comp.maturation.fg"
                ),
                design_space=list(mina=0,
                                  maxa=160
                ),
                parameters=list(
                  bpop=c(Base=1, EMAX = 100, EC50=7, Hill=2), # initial parameter guess not coming from previous step
                  manipulation=NULL # manipulation of initial parameters
                ),
                settings.db=list(
                  notfixed_sigma=c(1,0)
                ),
                settings.opt=list(
                  opt_xt=F,
                  opt_a=T,
                  opt_x=F,
                  bUseRandomSearch= 1,
                  bUseStochasticGradient = 1,
                  bUseBFGSMinimizer = 0,
                  bUseLineSearch = 1,
                  bUseExchangeAlgorithm=0,
                  EACriteria = 1,
                  compute_inv=T
                )
  ),
  simulate=list(target="NONMEM", model="NONMEM_files/ex1_sim.mod",
                data=list(
                  dosing = list(list(AMT=1000,Time=0)),
                  manipulation = manipulation = list(expression(AMT <- AMT0*AMT))
                )                      
                
  ),
  estimate=list(target="NONMEM", model="NONMEM_files/ex1_est_full.mod")
)


results_mbaod_true <- mbaod_simulate(cohorts=list(step_1), # only the sim/est step in this case.
                                      ncohorts=1, # number of steps or cohorts in one AOD, if greater than number of included cohorts, last step is repeated
                                      rep=10, #number of times to repeat the MBAOD simulation 
                                      name="PKPD_test",
                                      description="Test of Parameterization",
                                      seednr=123)